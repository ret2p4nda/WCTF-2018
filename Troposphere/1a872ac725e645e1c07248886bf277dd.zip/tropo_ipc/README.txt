The Tropophere 6 rocket will be equipped with a very new system secured by the
TrustZone.
Here is a test system that implements the future TrustZone IPC that will be
used by the TropoProcess.

It has been compiled and tested on ubuntu 18.04, you can start the test program
by typing the command "tropo_ipc"
