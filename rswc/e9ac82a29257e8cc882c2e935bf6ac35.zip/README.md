## How to build
```
$ docker build -t rswc ./docker
```

## How to launch
```
$ docker run --rm -it --pids-limit 10 -p 31337:31337 rswc
```
