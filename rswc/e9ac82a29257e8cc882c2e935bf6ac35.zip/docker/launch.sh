#!/bin/sh
cd /home/chall
exec /bin/sh -i
