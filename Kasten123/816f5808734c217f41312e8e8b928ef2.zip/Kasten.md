You can communicate with the server, find the bug and try to get the flag from this folder - /home/user/chal
IP：172.16.13.39
PORT：4444